from pydantic import BaseModel, UUID4, Field
from typing import List


# Allowed access levels (application-level validation)
ALLOWED_ACCESS_LEVELS = ["none", "read", "full"]


class PagePermissionItem(BaseModel):
    """Schema for a single page permission."""
    page_id: UUID4
    access: str = Field(..., description="Must be one of: none, read, full")


class SetPermissionsRequest(BaseModel):
    """Schema for setting user page permissions."""
    permissions: List[PagePermissionItem]
    
    class Config:
        json_schema_extra = {
            "example": {
                "permissions": [
                    {"page_id": "123e4567-e89b-12d3-a456-426614174000", "access": "full"},
                    {"page_id": "223e4567-e89b-12d3-a456-426614174001", "access": "read"}
                ]
            }
        }


class PagePermissionResponse(BaseModel):
    """Schema for page permission response."""
    id: UUID4
    user_id: UUID4
    page_id: UUID4
    access: str
    
    class Config:
        from_attributes = True
