# Import all API routers
from app.api.auth import router as auth_router
from app.api.admin_users import router as admin_users_router

__all__ = [
    "auth_router",
    "admin_users_router",
]
