# Import all models here for Alembic to detect them
from app.models.user import User
from app.models.auth import AuthRefreshToken
from app.models.page import Page
from app.models.permission import UserPagePermission
from app.models.audit import UserAuditLog

__all__ = [
    "User",
    "AuthRefreshToken",
    "Page",
    "UserPagePermission",
    "UserAuditLog",
]
