from sqlalchemy.orm import Session
from typing import Dict, Any, Optional
from datetime import datetime, timezone
import json

from app.models.audit import UserAuditLog


def create_audit_log(
    db: Session,
    admin_user_id: str,
    target_user_id: str,
    action: str,
    before_state: Optional[Dict[str, Any]] = None,
    after_state: Optional[Dict[str, Any]] = None
) -> UserAuditLog:
    """
    Create an audit log entry for user management actions.
    
    Args:
        db: Database session
        admin_user_id: UUID of the admin performing the action
        target_user_id: UUID of the user being modified
        action: Description of the action (e.g., "create_user", "update_user")
        before_state: State before the action (optional)
        after_state: State after the action (optional)
    
    Returns:
        Created audit log entry
    """
    audit_log = UserAuditLog(
        admin_user_id=admin_user_id,
        target_user_id=target_user_id,
        action=action,
        before_json=before_state,
        after_json=after_state
    )
    
    db.add(audit_log)
    db.commit()
    db.refresh(audit_log)
    
    return audit_log
